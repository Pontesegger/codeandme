package com.codeandme.debugger.textinterpreter.debugger.events.debugger;

/**
 * Pure marker interface for events triggered by the debugger, to be handled by
 * the model.
 */
public interface IDebuggerEvent {
}
