package com.codeandme.debugger.textinterpreter.debugger.events.debugger;

import com.codeandme.debugger.textinterpreter.debugger.events.AbstractEvent;

public class DebuggerStartedEvent extends AbstractEvent implements IDebuggerEvent {
}
