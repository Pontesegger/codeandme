This project is missing the required jar files.
Please checkout [1] to find the download locations for the required jars.
The list of jars is provided in META-INF/MANIFEST.MF

[1] https://codeandme.blogspot.com/2019/11/jakarta-microprofile-rest-client-in.html