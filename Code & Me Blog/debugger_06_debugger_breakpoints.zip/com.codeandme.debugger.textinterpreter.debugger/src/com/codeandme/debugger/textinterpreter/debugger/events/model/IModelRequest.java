package com.codeandme.debugger.textinterpreter.debugger.events.model;

/**
 * Pure marker interface for events triggered by the model, to be handled by the debugger.
 */
public interface IModelRequest {
}
