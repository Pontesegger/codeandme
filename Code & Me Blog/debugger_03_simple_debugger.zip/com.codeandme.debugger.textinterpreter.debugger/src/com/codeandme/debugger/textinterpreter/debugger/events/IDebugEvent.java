package com.codeandme.debugger.textinterpreter.debugger.events;

public interface IDebugEvent {
}
