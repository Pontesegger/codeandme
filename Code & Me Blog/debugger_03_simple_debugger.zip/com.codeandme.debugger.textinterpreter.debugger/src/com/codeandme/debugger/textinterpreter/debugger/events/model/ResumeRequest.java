package com.codeandme.debugger.textinterpreter.debugger.events.model;

import com.codeandme.debugger.textinterpreter.debugger.events.AbstractEvent;

public class ResumeRequest extends AbstractEvent implements IModelRequest {
}
